package br.com.adailsonteck.tv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.Executors

data class Channel(val name: String, val url: String, val group: String = "Canais")

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private val io = Executors.newSingleThreadExecutor()
    private val channels = mutableListOf<Channel>()
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 14f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8))
    }
    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText; setSingleLine(true); textSize = 14f
        setTextColor(Color.WHITE); setHintTextColor(0xFF9AA9C4.toInt())
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(0xFF18243A.toInt())
    }
    private fun button(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue; setOnClickListener { action() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 16, 34)
        window.navigationBarColor = Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 16, 34))
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }
        page.addView(label("ADAILSON TECK", 25f))
        page.addView(label("TV AO VIVO  •  FILMES  •  SÉRIES", 12f))

        val m3u = field("URL da lista M3U autorizada")
        page.addView(m3u)
        page.addView(button("CARREGAR LISTA M3U") {
            val url = m3u.text.toString().trim()
            if (url.isNotBlank()) loadM3u(url) else toast("Informe a URL M3U")
        })

        val server = field("Servidor Xtream (ex.: https://servidor.com)")
        val user = field("Usuário Xtream")
        val pass = field("Senha Xtream")
        page.addView(server); page.addView(user); page.addView(pass)
        page.addView(button("ENTRAR COM XTREAM CODES") {
            val s = server.text.toString().trim().trimEnd('/')
            val u = user.text.toString().trim()
            val p = pass.text.toString().trim()
            if (s.isNotBlank() && u.isNotBlank() && p.isNotBlank()) loadXtream(s, u, p)
            else toast("Preencha servidor, usuário e senha")
        })

        status = label("Adicione uma lista M3U ou entre com Xtream Codes.")
        page.addView(status)
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(210))
            setBackgroundColor(Color.BLACK)
        }
        page.addView(playerView)

        list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.rgb(7, 16, 34))
        }
        page.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        list.setOnItemClickListener { _, _, position, _ -> play(channels[position]) }
        setContentView(page)
    }

    private fun loadM3u(url: String) {
        status.text = "Carregando lista M3U..."
        io.execute {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val body = response.body?.string() ?: error("Lista vazia")
                    val parsed = parseM3u(body)
                    runOnUiThread { showChannels(parsed, "M3U") }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro ao carregar M3U: ${e.message}" }
            }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = "Canal"
        var group = "Canais"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",").trim().ifBlank { "Canal" }
                group = Regex("""group-title="([^"]*)"""").find(line)?.groupValues?.get(1) ?: "Canais"
            } else if (line.isNotBlank() && !line.startsWith("#") &&
                (line.startsWith("http://") || line.startsWith("https://"))) {
                out.add(Channel(name, line, group))
            }
        }
        return out
    }

    private fun loadXtream(server: String, username: String, password: String) {
        status.text = "Consultando canais Xtream..."
        io.execute {
            try {
                val u = URLEncoder.encode(username, "UTF-8")
                val p = URLEncoder.encode(password, "UTF-8")
                val url = "$server/player_api.php?username=$u&password=$p&action=get_live_streams"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val arr = JSONArray(response.body?.string() ?: "[]")
                    val parsed = mutableListOf<Channel>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("stream_id")
                        val title = item.optString("name", "Canal")
                        val ext = item.optString("container_extension", "ts").ifBlank { "ts" }
                        val cat = item.optString("category_name", "TV ao vivo")
                        parsed.add(Channel(title, "$server/live/$username/$password/$id.$ext", cat))
                    }
                    runOnUiThread { showChannels(parsed, "Xtream") }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro Xtream: ${e.message}" }
            }
        }
    }

    private fun showChannels(items: List<Channel>, source: String) {
        channels.clear(); channels.addAll(items)
        status.text = "$source: ${items.size} canais carregados"
        list.adapter = object : ArrayAdapter<Channel>(this, android.R.layout.simple_list_item_1, channels) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                return (convertView as? TextView ?: TextView(this@MainActivity)).apply {
                    text = "▶  ${getItem(position)?.name}\n     ${getItem(position)?.group}"
                    setTextColor(Color.WHITE); textSize = 15f
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                    setBackgroundColor(if (position % 2 == 0) 0xFF101D33.toInt() else 0xFF0B172B.toInt())
                }
            }
        }
    }

    private fun play(channel: Channel) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build()
                playerView.player = player
            }
            player?.setMediaItem(MediaItem.fromUri(channel.url))
            player?.prepare()
            player?.play()
            status.text = "Reproduzindo: ${channel.name}"
        } catch (e: Exception) { toast("Não foi possível reproduzir: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        io.shutdown()
        super.onDestroy()
    }
}
